package com.myApp.LogInService.Service;

import com.myApp.LogInService.Repo.UserRepo;
import com.myApp.LogInService.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LogInService {

    @Autowired
    UserRepo userRepo;

    public String registerUser(User user) {
        // Check if all fields are filled
        if (user.getFirstName().isEmpty() || user.getLastName().isEmpty() || user.getGender().isEmpty()
                || user.getUsername().isEmpty() || user.getPassword().isEmpty()) {
            return "Error: All fields are required.";
        }

        // Check if password matches with confirm password
        if (!user.getPassword().equals(user.getConfirmPassword())) {
            return "Error: Passwords do not match.";
        }

        // Save the user to the database
        userRepo.save(user);
        return "Registration successful.";
     }

    public String loginUser(String username, String password) {
        User user = userRepo.findByUsername(username);

        if (user == null) {
            return "Error: User not found.";
        }

        if (!user.getPassword().equals(password)) {
            return "Error: Incorrect password.";
        }

        return "Login successful.";
    }
}
