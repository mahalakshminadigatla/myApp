package com.myApp.LogInService.Controller;

import com.myApp.LogInService.Service.LogInService;
import com.myApp.LogInService.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin("*")
@RequestMapping("/users")
public class UserController {
    @Autowired
    private LogInService logInService;

    @PostMapping("/register")
    public String registerUser(@RequestBody User user) {
        return logInService.registerUser(user);
    }

    @PostMapping("/login")

    public String loginUser( @RequestBody User user) {
        String username = user.getUsername();
        String password = user.getPassword();
        return logInService.loginUser(username, password);

    }
}

