package com.myApp.LogInService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LogInServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
